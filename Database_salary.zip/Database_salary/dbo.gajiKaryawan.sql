﻿CREATE TABLE [dbo].[Gaji Karyawan]
(
	[nama_karyawan] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [nip_karyawan] INT NOT NULL, 
    [gajiPokok_karyawan] INT NOT NULL, 
    [masaKerja_karyawan] INT NOT NULL
)
